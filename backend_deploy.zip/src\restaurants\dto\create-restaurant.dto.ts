export class CreateRestaurantDto {}
